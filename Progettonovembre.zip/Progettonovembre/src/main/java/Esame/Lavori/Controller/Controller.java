package Esame.Lavori.Controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Vector;

import org.apache.tomcat.util.json.JSONParser;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Esame.Lavori.ApiData.*;
import Esame.Lavori.Model.*;
import Esame.Lavori.Model.StatsFilters.*;

@RestController
public class Controller {

	
	@Autowired 

	/*
	 * GetMapping che ha la funzionen di convertire i JSON in file di testo
	 * in modo da poterli poi manipolare
	 */
	@GetMapping("/download")
	void getWorks() 
	{

		ApiConnection acns = null;

		try {
			
			String[] citta = {"San Francisco", "Chicago", "Boston", "Los Angeles", "Houston"};
			String[] parola_chiave = {"Python","Java", "Sql"};
			
			for(int i = 0; i<citta.length; i++){
				
				for( int k = 0; k<parola_chiave.length; k++) {
				
				acns = new ApiConnection ( citta[i], parola_chiave[k]);
				acns.savefile();
				
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	/*@GetMapping("/jobs")
	void getPython(@RequestParam(name = "city" ) String citta) throws IOException {
		

		StatsLavori python = null;
		
		python = new StatsLavori(citta);
		python.metodo_lavori();
		python.Remoto();
		python.Grandezza_azienda();
		python.Contratti(); 
	}
	*/

	@GetMapping("/Python")
	public FiltersLavori getLavoriPython(
			@RequestParam(name = "city") String citta, @RequestParam(name = "remoto") String remoto,
			@RequestParam(name = "contratto") String contratto, @RequestParam(name = "dipendenti") String dipendenti)
	{
		FiltersLavori py = null;
		
		py = new FiltersLavori(citta);
		py.filtra_remoto(remoto);
		py.filtra_contratto(contratto);
		py.filtra_azienda(dipendenti);
		return py;
		
		}
	
}