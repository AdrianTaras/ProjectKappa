package Esame.Lavori.Service;

public interface JobService {

}
