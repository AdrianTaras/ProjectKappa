package Esame.Lavori.ApiData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;



import Esame.Lavori.Model.DownloadCity;

public class ApiConnection {

	private Vector<DownloadCity> info_aziende = new Vector<DownloadCity>();
	
	private String citta = null;
	private String key_word = null;

	public ApiConnection( String citta, String key_word ) throws IOException, ParseException {

		this.citta = citta;
		this.key_word = key_word;


		try {

			URLConnection openConnection = new URL("https://findwork.dev/api/jobs/?format=json&search="+ this.key_word +"&location=" + this.citta + "&order_by=date").openConnection();
			openConnection.addRequestProperty("Authorization", "Token 226b15f6b2b453b61c607360d76ccb2469a9b5d8");
			InputStream in = openConnection.getInputStream();	

			String data = "";
			String line = "";

			try {
				InputStreamReader inR = new InputStreamReader( in );
				BufferedReader buf = new BufferedReader( inR );

				while ( ( line = buf.readLine() ) != null ) {
					data+= line;
				}
			} finally {
				in.close();
			}

			JSONObject obj = (JSONObject) JSONValue.parseWithException(data);

			JSONArray lavori = (JSONArray)obj.get("results");

			DownloadCity dwnl_city;

			for(int i = 0; i < lavori.size(); i++) {

				dwnl_city = new DownloadCity();

				JSONObject oggetto_lavoro = (JSONObject) lavori.get(i);

				if(oggetto_lavoro.get("company_num_employees")!=null) {
					String numero_dipendenti = (oggetto_lavoro.get("company_num_employees").toString());
					dwnl_city.setCompany_num_employees(numero_dipendenti);
				}
				else dwnl_city.setCompany_num_employees("unknown");

				if(oggetto_lavoro.get("employment_type")!= null) {

					String tipo_contratto = (oggetto_lavoro.get("employment_type").toString());
					dwnl_city.setEmployment_type(tipo_contratto);
				}
				else dwnl_city.setEmployment_type("unknown");

				if(oggetto_lavoro.get("location") != null) {
					String posizione = (oggetto_lavoro.get("location").toString());
					dwnl_city.setCity_name(posizione);
				}
				else dwnl_city.setCity_name("null");

				if (oggetto_lavoro.get("remote") != null) {
					if ((boolean)oggetto_lavoro.get("remote"))dwnl_city.setRemote("true");
					else dwnl_city.setRemote("false");
				}
				else dwnl_city.setRemote("unknown");
				
				String nome_azienda = oggetto_lavoro.get("company_name").toString();
				dwnl_city.setCompany_name(nome_azienda);
				
				String ruolo = oggetto_lavoro.get("role").toString();
				dwnl_city.setRole(ruolo);
				
				String data_aggiunta = oggetto_lavoro.get("date_posted").toString();
				dwnl_city.setDate_posted(data_aggiunta);
				
				info_aziende.add(dwnl_city);
			}
		} catch(Exception e) {
			System.out.print(e);
		}
	}

	public void savefile() {

		try {

			PrintWriter file_output = new PrintWriter(new BufferedWriter(new FileWriter("C:\\Users\\loren\\OneDrive\\Desktop\\Lavori\\Resources\\"+this.key_word+"\\" + this.citta + ".txt")));

			for (int i = 0; i <info_aziende.size(); i++) {
				file_output.println(info_aziende.get(i).getCity_name());
				file_output.println(info_aziende.get(i).getEmployment_type());
				file_output.println(info_aziende.get(i).getCompany_num_employees());
				file_output.println(info_aziende.get(i).getRemote());
				file_output.println(info_aziende.get(i).getCompany_name());
				file_output.println(info_aziende.get(i).getRole());
				file_output.println(info_aziende.get(i).getDate_posted());
			}

			file_output.close();
		}

		catch(IOException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			System.out.println(e);

		}
	}

	/*public String readVectors() {
		String lunga = "";
		for (int i = 0; i<info_aziende.size(); i++) {
			System.out.println(info_aziende.get(i).getCity_name() + " " + info_aziende.get(i).getCompany_num_employees());
		}
		return lunga;
	}*/
}







