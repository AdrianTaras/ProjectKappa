package Esame.Lavori.Model.StatsFilters;

import java.io.FileNotFoundException;
import java.util.HashMap;

/*
 * Classe astratta che inizializza le HashMap che verrano poi usate nella classe StatsLAvori
 * 
 */
public abstract class Stats {
	
	protected HashMap <String, String> lavori_generale = new HashMap<String, String>();
	protected HashMap <String, Double> stats_remoto = new HashMap<String, Double>();
	protected HashMap <String, Double> stats_g_azienda = new HashMap<String, Double>();
	protected HashMap <String, Double> stats_contratto = new HashMap<String, Double>();
	
	/*
	 * Il metodo si occupa di creare la Hashmap contenente i risultati delle ricerche.
	 * @Returnla la HashMap contenente i risultati della ricerca
	 */
	public abstract HashMap <String, String> metodo_lavori();
	
	/*
	 * Il metodo si occuopa di creare le percentuali di lavori da remoto, non da remoto e unknown
	 * @Return la HashMap contentente le percentuali.
	 */
	public abstract HashMap<String, Double> Remoto();
	
	/*
	 * Il metodo si occuopa di creare le percentuali sulla grandezza delle aziende, in particolare se hanno 1-10, 11-50, 51-100, 100+ dipendenti
	 * @Return la HashMap contentente le percentuali.
	 */
	public abstract HashMap<String, Double> Grandezza_azienda();
	
	/*
	 * Il metodo si occuopa di creare le percentuali sui contratti offerti dalle aziende: full time, part time, unknown.
		 * @Return la HashMap contentente le percentuali.
	 */
	public abstract HashMap<String, Double> Contratti();

	
	
	}
