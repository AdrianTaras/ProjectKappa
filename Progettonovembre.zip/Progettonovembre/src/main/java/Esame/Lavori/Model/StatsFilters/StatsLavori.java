package Esame.Lavori.Model.StatsFilters;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;
import Esame.Lavori.Model.DownloadCity;

/*
 * Classe che utilizza le HashMap della classe Stats per poter fornire tutte le 
 * statistiche richieste dall'utente
 */
public  class StatsLavori extends Stats {

	private Vector<DownloadCity> lavori = new Vector<>();
	private String citta;
	DownloadCity l_;
	
	/*
	 * Il metodo si occupa di inserire nei vettori i valori presenti nei file di testo precedentemente creati.
	 * @Param citta indica la citta sulla quale prendere i dati.
	 */
	public StatsLavori(String citta) {
		
		this.citta = citta;
		try
		{
			
			Scanner scanner = new Scanner(new BufferedReader(new FileReader(".\\Lavori\\Resources\\Python\\" + this.citta + ".txt")));
			
			while (scanner.nextLine() != null) {
				l_.setCity_name(scanner.nextLine());
				l_.setEmployment_type(scanner.nextLine());
				l_.setCompany_num_employees(scanner.nextLine());
				l_.setRemote(scanner.nextLine());
				l_.setCompany_name(scanner.nextLine());
				l_.setRole(scanner.nextLine());
				l_.setDate_posted(scanner.nextLine());
				
				lavori.add(l_);
			}
			
		}
		
		catch(FileNotFoundException e){
			System.out.print(e);
	}catch(Exception e){
		System.out.print(e);
	}
		
	}
	
	
	public HashMap<String, String> metodo_lavori(){
	
		for(int i = 0; i< lavori.size() ; i++) 
		
		{
			lavori_generale.put("nome_azienda:",lavori.get(i).getCity_name());
			lavori_generale.put("tpo_contratto:",lavori.get(i).getEmployment_type());
			lavori_generale.put("numero_dipendenti:",lavori.get(i).getCompany_num_employees());
			lavori_generale.put("remoto:",lavori.get(i).getRemote());
			lavori_generale.put("feels_like:",lavori.get(i).getCompany_name());
			lavori_generale.put("temperature_min:",lavori.get(i).getRole());
			lavori_generale.put("temperature_max:",lavori.get(i).getDate_posted());
			System.out.println(lavori_generale);
		}
		
		return lavori_generale;
	}
	

	
	public HashMap<String, Double> Remoto() {
		
		double unknown = 0;
		double falso = 0;
		double vero = 0;
		
		for(int i = 0; i<lavori.size(); i++) {
			
			if (lavori.get(i).getRemote() != "unknown") {
				
				if (lavori.get(i).getRemote() != "true") {
					falso++;
				}
				   else vero++;
			}
			else unknown++;
		}
		double percent= ( unknown + falso + vero )/ 100;
		stats_remoto.put("% da remoto: ", (vero) / percent);
		stats_remoto.put("% non da remoto:  ", (falso) / percent);
		stats_remoto.put("% unknown: ",(unknown) / percent);
		System.out.println(stats_remoto);
	return stats_remoto;
	
	}
	
	
public HashMap<String, Double> Grandezza_azienda() {
		
		double unknown = 0;
		double uno_dieci = 0;
		double undici_cinquanta = 0;
		double cin_uno_cento = 0;
		double cento_piu = 0;
		
		for(int i = 0; i<lavori.size(); i++) {
			
			if (lavori.get(i).getCompany_num_employees() != "unknown") {
				
				if (lavori.get(i).getCompany_num_employees() != "1-10") {
					
					if(lavori.get(i).getCompany_num_employees() != "11-50") {
						
						if (lavori.get(i).getCompany_num_employees() != "51-100") {
							cento_piu++;
						}cento_piu++;
					} cin_uno_cento++;
					
				}
				   else uno_dieci++;
			}
			else unknown++;
		}
		double percent= ( unknown + uno_dieci + undici_cinquanta + cin_uno_cento + cento_piu)/ 100;
		stats_g_azienda.put("% azienda da 1-10 dipendenti: ", (uno_dieci) / percent);
		stats_g_azienda.put("% azienda da 11-50 dipendenti: ", (undici_cinquanta) / percent);
		stats_g_azienda.put("% azienda da 51-100 dipendenti: ", (cin_uno_cento) / percent);
		stats_g_azienda.put("% azienda da 100+ dipendenti: ", (cento_piu) / percent);
		stats_g_azienda.put("% unknown: ",(unknown) / percent);
		
		System.out.println(stats_g_azienda);
		
	return stats_g_azienda;
	
	}


public HashMap<String, Double> Contratti(){
	
	double unknown = 0;
	double full = 0;
	double part = 0;
	
	for(int i = 0; i<lavori.size(); i++) {
		
		if (lavori.get(i).getEmployment_type() != "unknown") {
			
			if (lavori.get(i).getEmployment_type() != "full time") {
				part++;
			}
			   else full++;
		}
		else unknown++;
	}
	double percent= ( unknown + part + full )/ 100;
	stats_contratto.put("% full time: ", (full) / percent);
	stats_contratto.put("% part time:  ", (part) / percent);
	stats_contratto.put("% unknown: ",(unknown) / percent);
	
	System.out.println(stats_contratto);
	
	return stats_contratto;
	
}
}

