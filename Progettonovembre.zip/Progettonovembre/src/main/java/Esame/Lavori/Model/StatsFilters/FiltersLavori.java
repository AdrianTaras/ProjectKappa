package Esame.Lavori.Model.StatsFilters;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;
import Esame.Lavori.Model.DownloadCity;


public class  FiltersLavori {

	private Vector<DownloadCity> lavori = new Vector<>();
	private Vector<DownloadCity> lavori_filtratti_da_citta = new Vector<>();
	private Vector<DownloadCity> lavori_filtrati_da_remoto = new Vector<>();
	private Vector<DownloadCity> lavori_filtrati_da_contratto = new Vector<>();
	private Vector<DownloadCity> lavori_filtrati_da_grandezza_azienda = new Vector<>();
	private String citta;
	private String remoto;
	private String contratto;
	private String num_dipendenti;
	
	DownloadCity l_;
	DownloadCity l_citta;
	DownloadCity l_remoto;
	DownloadCity l_contratto;
	DownloadCity l_dipendenti;
	
	/*
	 * Il metodo si occupa di inserire nei vettori i valori presenti nei file di testo precedentemente creati.
	 * @Param citta indica la citta sulla quale prendere i dati.
	 */

	public FiltersLavori(String citta) {
		
		this.citta = citta;
		try
		{
			
			Scanner scanner = new Scanner(new BufferedReader(new FileReader(".\\Lavori\\Resources\\Python\\" + this.citta + ".txt")));
			
			while (scanner.nextLine() != null) {
				l_.setCity_name(scanner.nextLine());
				l_.setEmployment_type(scanner.nextLine());
				l_.setCompany_num_employees(scanner.nextLine());
				l_.setRemote(scanner.nextLine());
				l_.setCompany_name(scanner.nextLine());
				l_.setRole(scanner.nextLine());
				l_.setDate_posted(scanner.nextLine());
				
				lavori.add(l_);
			}
			
		}
		
		catch(FileNotFoundException e){
			System.out.print(e);
	}catch(Exception e){
		System.out.print(e);
	}
		
	}
	
	

	/*public void filtra_citta (String citta){
		
		this.citta=citta;
		
		for(int i = 0; i< lavori.size() ; i++) 
		
		{
			if (lavori.get(i).getCity_name() == this.citta) {
				
				l_citta.setCity_name(lavori.get(i).getCity_name());
				l_citta.setCompany_name(lavori.get(i).getEmployment_type());
				l_citta.setCompany_num_employees(lavori.get(i).getCompany_num_employees());
				l_citta.setDate_posted(lavori.get(i).getDate_posted());
				l_citta.setEmployment_type(lavori.get(i).getEmployment_type());
				l_citta.setRemote(lavori.get(i).getRemote());
				l_citta.setRole(lavori.get(i).getRole());
				lavori_filtratti_da_citta.add(l_citta);				
			}
			
		}
	}*/
	

	public Vector<DownloadCity> filtra_remoto(String remoto){
		
		this.remoto = remoto;
		
		for(int i = 0; i< lavori_filtratti_da_citta.size() ; i++) 
			
		{
			if (lavori_filtratti_da_citta.get(i).getRemote() == this.remoto) {
				
				l_remoto.setCity_name(lavori_filtratti_da_citta.get(i).getCity_name());
				l_remoto.setCompany_name(lavori_filtratti_da_citta.get(i).getEmployment_type());
				l_remoto.setCompany_num_employees(lavori_filtratti_da_citta.get(i).getCompany_num_employees());
				l_remoto.setDate_posted(lavori_filtratti_da_citta.get(i).getDate_posted());
				l_remoto.setEmployment_type(lavori_filtratti_da_citta.get(i).getEmployment_type());
				l_remoto.setRemote(lavori_filtratti_da_citta.get(i).getRemote());
				l_remoto.setRole(lavori_filtratti_da_citta.get(i).getRole());
				lavori_filtrati_da_remoto.add(l_remoto);				
			}
			
		}
		return lavori_filtrati_da_remoto;
	}
	
	
	public Vector<DownloadCity> filtra_contratto(String contratto){
		
		this.contratto = contratto;
		
		for(int i = 0; i< lavori_filtrati_da_remoto.size() ; i++) 
			
		{
			if (lavori_filtrati_da_remoto.get(i).getEmployment_type() == this.contratto || lavori_filtrati_da_remoto.get(i).getEmployment_type() == "unknown" ) {
				
				l_contratto.setCity_name(lavori_filtrati_da_remoto.get(i).getCity_name());
				l_contratto.setCompany_name(lavori_filtrati_da_remoto.get(i).getEmployment_type());
				l_contratto.setCompany_num_employees(lavori_filtrati_da_remoto.get(i).getCompany_num_employees());
				l_contratto.setDate_posted(lavori_filtrati_da_remoto.get(i).getDate_posted());
				l_contratto.setEmployment_type(lavori_filtrati_da_remoto.get(i).getEmployment_type());
				l_contratto.setRemote(lavori_filtrati_da_remoto.get(i).getRemote());
				l_contratto.setRole(lavori_filtrati_da_remoto.get(i).getRole());
				lavori_filtrati_da_contratto.add(l_remoto);				
			}
			
		}
		return lavori_filtrati_da_contratto;
	}
	
	public Vector<DownloadCity> filtra_azienda(String num_dipendenti){
		
		this.num_dipendenti = num_dipendenti;
		
		for(int i = 0; i< lavori_filtrati_da_remoto.size() ; i++) 
			
		{
			if (lavori_filtrati_da_contratto.get(i).getCompany_num_employees() == this.num_dipendenti) {
				
				l_dipendenti.setCity_name(lavori_filtrati_da_contratto.get(i).getCity_name());
				l_dipendenti.setCompany_name(lavori_filtrati_da_contratto.get(i).getEmployment_type());
				l_dipendenti.setCompany_num_employees(lavori_filtrati_da_contratto.get(i).getCompany_num_employees());
				l_dipendenti.setDate_posted(lavori_filtrati_da_contratto.get(i).getDate_posted());
				l_dipendenti.setEmployment_type(lavori_filtrati_da_contratto.get(i).getEmployment_type());
				l_dipendenti.setRemote(lavori_filtrati_da_contratto.get(i).getRemote());
				l_dipendenti.setRole(lavori_filtrati_da_contratto.get(i).getRole());
				lavori_filtrati_da_grandezza_azienda.add(l_dipendenti);				
			}
			
		}
		return lavori_filtrati_da_grandezza_azienda;
	}
	
	
}
