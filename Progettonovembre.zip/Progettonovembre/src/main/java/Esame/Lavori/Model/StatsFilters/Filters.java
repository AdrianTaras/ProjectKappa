package Esame.Lavori.Model.StatsFilters;

import java.util.Vector;

import Esame.Lavori.Model.DownloadCity;

public abstract class Filters {
	
	public abstract  Vector<DownloadCity> filtra_remoto(String Remoto);
	
	public abstract  Vector<DownloadCity> filtra_contratto(String contratto);
	
	public abstract  Vector<DownloadCity> filtra_azienda(String num_dipendenti);
}
